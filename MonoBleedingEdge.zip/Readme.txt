this is the first game i made. i read "레트로의 유니티 게임 프로그래밍 에센스"
and practice how to use git commit.
and this line is to practice the remote repository.